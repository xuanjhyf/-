# 📤 怎么把这个仓库传到 GitHub（新手 10 分钟版）

> 你不需要懂命令行，跟着做就行。全程约 10 分钟。

---

## 第一步：注册 / 登录 GitHub

1. 打开 https://github.com
2. 没有账号就注册一个（用邮箱即可）
3. **建议用户名起得好一点**，比如 `he-yufei` / `yufei-ai`，因为以后要放进简历

---

## 第二步：在网页上新建仓库

1. 登录后，点右上角 **「+」→「New repository」**
2. 填写：
   - **Repository name**：`event-zero-ai-eval`（或 `ai-education-eval`）
   - **Description**（描述，会显示在仓库列表）：
     ```
     AI + 语文教育产品的评测体系 | 100 条垂直评测集 + 双轨打分 + badcase 归因闭环
     ```
   - 选 **Public**（公开，HR 才能看到）
   - ✅ 勾选 **「Add a README file」**——先勾上，后面我们覆盖它
   - 其他不用动
3. 点 **「Create repository」**

---

## 第三步：把文件传上去（最简单：网页拖拽）

**不用装 Git，不用敲命令！**

1. 进入刚建好的仓库页面
2. 点 **「Add file」→「Upload files」**
3. 把本地 `github-event-zero-eval/` 文件夹里的**所有文件和子文件夹**拖进去
   - ⚠️ 网页上传**不支持直接拖文件夹**，所以要分批：
     - 第一批：拖 `README.md`、`LICENSE`、`.gitignore`
     - 第二批：进 `eval_sets` 文件夹，把里面 4 个 md 拖进去（GitHub 会保留路径，但网页版可能丢结构，**更稳的做法是本地先打包 zip，见下方「推荐方法」**）

### ✅ 推荐方法：用 GitHub 网页的「Import」或直接桌面版

**最稳方案——用 GitHub Desktop（图形界面，5 分钟）**：

1. 下载安装 https://desktop.github.com
2. 打开 GitHub Desktop → 登录你的 GitHub 账号
3. **「File」→「Add Local Repository」** → 选择本地的 `github-event-zero-eval` 文件夹
   - 如果提示"not a git repository"，点 **「create a repository」**，路径选这个文件夹，其他默认，点 Create
4. 左侧会显示所有文件变更 → 下方填：
   - **Summary**：`feat: AI 语文教育评测体系 v1.0`
   - **Description**（可选）：`100 条评测集 + 双轨打分 + badcase 归因`
5. 点 **「Commit to main」**
6. 点顶部 **「Publish repository」** → 取消勾选 "Keep this code private"（要公开）→ Publish

搞定！刷新 GitHub 网页就能看到你的仓库了。

---

## 第四步：检查仓库长什么样

打开你的仓库地址（形如 `https://github.com/你的用户名/event-zero-ai-eval`），确认：

- ✅ README 正常显示（有徽章、目录、表格）
- ✅ `eval_sets/` 里 4 个评测集文件都在
- ✅ `metrics/`、`reports/`、`docs/`、`data/` 都有内容

> 💡 GitHub 会自动渲染 README.md 作为仓库首页，所以 README 写得好 = 仓库第一印象好。

---

## 第五步：把链接用起来

| 用在哪 | 怎么写 |
|--------|--------|
| **简历** | `GitHub：github.com/你的用户名/event-zero-ai-eval` |
| **求职信** | 见下方话术 |
| **面试** | 现场打开演示，讲评测闭环 |

**求职信可加的一句**：

> 我独立开发了 AI 语文教学 Agent「事件零岁」，并为它搭建了一套 100 条的垂直评测体系（含双轨打分、badcase 归因与迭代验证），完整记录在 GitHub：github.com/xxx/event-zero-ai-eval

---

## ⚠️ 注意事项

1. **仓库一定要 Public**，否则 HR 点开是 404
2. **真实个人信息**要不要放？简历里已有联系方式，README 里的手机号可以保留（方便 HR 联系），也可以删掉改邮箱
3. **示例数据 vs 真实数据**：`data/scoring_template.csv` 目前是示例，跑完真实评测后，把真实数据存成 `my_results.csv`（已在 .gitignore 里排除，不会误传）

---

## 🆘 常见问题

**Q：网页上传文件夹后结构乱了怎么办？**
A：删掉重来，用 GitHub Desktop 更稳。

**Q：README 里的表情/表格显示不出来？**
A：GitHub 支持 Emoji 和 Markdown 表格，正常显示。本地预览可用 Typora 或 VS Code。

**Q：我完全没有代码基础，这个仓库会不会显得"不像程序员"？**
A：**完全不会**。这个仓库的价值恰恰在于——它展示的是**产品思维和评测方法论**，不是代码能力。对 AI 产品经理岗位来说，这比一个玩具级 Python 脚本有价值得多。

**Q：要不要加 Star/好看的封面图？**
A：可以后续加。现阶段先把内容传上去，链接能用就行——**完成比完美重要**。
