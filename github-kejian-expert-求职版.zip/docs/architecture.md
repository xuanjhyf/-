# 架构 / 部署 / 接口

课件专家 v1.16.0 的工程化交付说明。

## 一、系统架构

```
┌────────────────────────────────────────────────────────┐
│  前端  ui/index.html (单文件)                            │
│   - 上传 / 认课文 / 预览 / 配色 / 门禁                    │
└──────────────┬─────────────────────────────────────────┘
               │ HTTP (localhost:8848)
┌──────────────▼─────────────────────────────────────────┐
│  后端  Flask  ui/server.py  +  ui/serve.py (零依赖)      │
│   - /api/status /api/identify /api/gate /api/scan ...    │
└──────────────┬─────────────────────────────────────────┘
               │
┌──────────────▼─────────────────────────────────────────┐
│  pipeline.py (skills/kejian-expert/scripts)             │
│   认课文 → 扫素材 → 定风格 → 出课件 → 门禁                 │
│   (RAG 双库：内置知识库 + 教师个人库)                     │
└──────────────┬─────────────────────────────────────────┘
               │
┌──────────────▼─────────────────────────────────────────┐
│  数据  data/  (SQLite kejian.db + uploads/)             │
│           assets/ (模板/清单 manifests, 素材)            │
└────────────────────────────────────────────────────────┘
```

## 二、部署方式

| 方式 | 说明 |
|------|------|
| Windows 双击 | start.bat（chcp 65001 + CRLF + 端口自检） |
| Unix / macOS | start.sh |
| Docker | docker-compose up -d（挂 data/out 卷，stop_grace_period 20s） |
| 健康检查 | /api/status + /health（探活 / 端口自检） |

## 三、接口契约（单一事实来源）

- GET /api/status · GET /api/templates?lib= · GET /api/uploads
- POST /api/upload?lib=（真落盘 + 落库）· POST /api/migrate · POST /api/scan
- POST /api/palette · POST /api/clean · POST /api/request · POST /api/identify · POST /api/gate

## 四、异常处理策略

| 场景 | 行为 |
|------|------|
| 后端连不上 | 前端横幅 + 友好提示（仅 5xx） |
| 端口漂移 | 按 health 自动找真服务回连 |
| 缺字 / 坏数据 | 显式「缺字」警告横幅 + 插页提示，不静默 |
| pipeline 失败 | 回传 stdout/stderr/堆栈，可定位 |
| 编码 GBK 崩溃 | 强制 UTF-8 + 双通道结果（stdout+落盘） |

## 五、可验证性

- 9 个 verify 脚本：start_bat / graceful / docker / missing_warning / api_bridge / e2e_browser / encoding_gbk / pack
- E2E 走真服务 + 真 DOM
- Docker HEALTHCHECK 探活

这套结构的目标是：让产品在任意环境里都能被验证、被部署、被观测。这一点决定它算不算"真产品"。